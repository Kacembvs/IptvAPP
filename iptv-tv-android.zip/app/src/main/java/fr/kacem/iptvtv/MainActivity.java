package fr.kacem.iptvtv;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView w;

    private static Map<String, String> cors() {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        return h;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            // Relais natif : https://app.local/p?u=<url> -> requête faite par l'app (sans CORS)
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("app.local".equals(u.getHost()) && "/p".equals(u.getPath())) {
                    try {
                        HttpURLConnection c = (HttpURLConnection) new URL(u.getQueryParameter("u")).openConnection();
                        c.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20");
                        c.setConnectTimeout(20000);
                        c.setReadTimeout(120000);
                        int code = c.getResponseCode();
                        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                        if (in == null) in = new ByteArrayInputStream(new byte[0]);
                        String ct = c.getContentType();
                        String mime = ct == null ? "application/octet-stream" : ct.split(";")[0].trim();
                        return new WebResourceResponse(mime, "utf-8", code, "OK", cors(), in);
                    } catch (Exception e) {
                        return new WebResourceResponse("text/plain", "utf-8", 502, "ERR", cors(),
                                new ByteArrayInputStream(("ERR " + e).getBytes()));
                    }
                }
                return super.shouldInterceptRequest(v, r);
            }
        });
        w.loadUrl("file:///android_asset/tv.html");
    }

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_BACK) {
            w.evaluateJavascript("window.__back?window.__back():false", v -> {
                if (!"true".equals(v)) finish();
            });
            return true;
        }
        return super.onKeyDown(k, e);
    }
}
