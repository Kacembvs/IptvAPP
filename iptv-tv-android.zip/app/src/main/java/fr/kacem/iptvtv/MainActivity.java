package fr.kacem.iptvtv;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    // Si ce fichier existe dans le dépôt GitHub public, l'écran est mis à jour sans réinstaller l'APK.
    private static final String UPDATE_URL = "https://raw.githubusercontent.com/Kacembvs/IptvAPP/main/tv.html";
    private static final String UA = "VLC/3.0.20 LibVLC/3.0.20";

    private WebView w;

    private static Map<String, String> cors() {
        Map<String, String> h = new HashMap<String, String>();
        h.put("Access-Control-Allow-Origin", "*");
        return h;
    }

    // Ouvre une URL en suivant les redirections (y compris http -> https).
    private static HttpURLConnection open(String url) throws Exception {
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestProperty("User-Agent", UA);
            c.setConnectTimeout(20000);
            c.setReadTimeout(120000);
            c.setInstanceFollowRedirects(false);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                if (loc == null) return c;
                url = new URL(new URL(url), loc).toString();
                c.disconnect();
                continue;
            }
            return c;
        }
        throw new Exception("trop de redirections");
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            // Relais natif : https://app.local/p?u=<url> -> requête faite par l'app, sans restriction CORS
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("app.local".equals(u.getHost()) && "/p".equals(u.getPath())) {
                    try {
                        HttpURLConnection c = open(u.getQueryParameter("u"));
                        int code = c.getResponseCode();
                        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                        if (in == null) in = new ByteArrayInputStream(new byte[0]);
                        String ct = c.getContentType();
                        String mime = ct == null ? "application/octet-stream" : ct.split(";")[0].trim();
                        return new WebResourceResponse(mime, "utf-8", code, "OK", cors(), in);
                    } catch (Exception e) {
                        return new WebResourceResponse("text/plain", "utf-8", 502, "ERR", cors(),
                                new ByteArrayInputStream(("ERR " + e).getBytes()));
                    }
                }
                return super.shouldInterceptRequest(v, r);
            }
        });
        loadApp();
    }

    // Télécharge la dernière version de l'écran (si disponible), sinon utilise celle de l'APK.
    private void loadApp() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                File f = new File(getFilesDir(), "tv.html");
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_URL).openConnection();
                    c.setConnectTimeout(5000);
                    c.setReadTimeout(8000);
                    if (c.getResponseCode() == 200) {
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        InputStream in = c.getInputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                        in.close();
                        String txt = bo.toString("UTF-8");
                        if (txt.contains("</html>") && txt.contains("<title>IPTV")) {
                            FileOutputStream fo = new FileOutputStream(f);
                            fo.write(bo.toByteArray());
                            fo.close();
                        }
                    }
                } catch (Exception e) {
                    // hors ligne ou dépôt privé : on garde la version déjà présente
                }
                final String url = f.exists() ? "file://" + f.getAbsolutePath() : "file:///android_asset/tv.html";
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        w.loadUrl(url);
                    }
                });
            }
        }).start();
    }

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_BACK) {
            w.evaluateJavascript("window.__back?window.__back():false", new android.webkit.ValueCallback<String>() {
                @Override
                public void onReceiveValue(String v) {
                    if (!"true".equals(v)) finish();
                }
            });
            return true;
        }
        return super.onKeyDown(k, e);
    }
}
